<?php
    function drawHeader(){
        session_start();
    }
?>

    <!Doctype html>
    <html lang="en-US">

    <head>
        <meta charset="UTF-8">
        <title>My Website</title>
        <link rel="stylesheet" href="css/style.css">
    </head>

    <body>
        <header>
            <h1>My Website</h1>
        </header>
   
<?php function drawFooter() { ?>
    <footer>
        <p>My Website &copy; 2023</p>
    </footer>
  </body>
</html>
<?php } ?>


<?php
    function drawLoginForm(){
        //depois temos de mexer no href
        ?>
        <form action="actions/login.php" method="post" class="login">
            <input type="email" name="email" placeholder="email">
            <input type="password" name="password" placeholder="password">
            <a href="register.php">Register</a>
            <input type="submit" value="Login">
        </form>
        <?php
    }
?>

<?php
    //depois temos de mexer no href
    function drawLogout(){
        ?>
        <form action="actions/logout.php" method="post" class="logout">
            <a href="profile.php"><?=$session->getName()?></a>
            <input type="submit" value="Logout">
        </form>
        <?php
    }
?>

