<?php

    declare (strict_types=1);

    require_once(__DIR__ . '/../utils/session.php');

    $session = new Session();

    //require da connection da database e da user class
    require_once(__DIR__ . 'database/connection.php');

    $db = getDbConnection();

    $user= User::getUserByPass($db, $_POST['email'], $_POST['password']);

    if($user){
        $session->setId($user->getId());
        $session->setName($user->getName());
        $session->addMessage('success', 'Login successful!');
    } else {
        $session->addMessage('success', 'Login successful!');
    }

    header('Location: ' . $_SERVER['HTTP_REFERER']);
?>