<?php
  header('Location: pages');
?>