<?php
    declare (strict_types=1);

    class User{
        public int $id;
        public string $first_name;
        public string $last_name;
        public string $email;
        public string $gender;
        public string $password;
        public string $username;
        public boolval $is_client;
        public boolval $is_agent;
        public boolval $is_admin;
        

        public function __construct(int $id, string $first_name, string $last_name, string $email, string $password, string $username, boolval $is_client, boolval $is_agent, boolval $is_admin){
            $this->id = $id;
            $this->first_name = $first_name;
            $this->last_name = $last_name;
            $this->email = $email;
            $this->password = $password;
            $this->username = $username;
            $this->is_client = $is_client;
            $this->is_agent = $is_agent;
            $this->is_admin = $is_admin;
        }

        function name(){
            return $this->first_name . ' ' . $this->last_name;
        }

        function save($db){
            $stmt = $db->prepare('
        UPDATE Customer SET FirstName = ?, LastName = ?
        WHERE CustomerId = ?
        ');
            $stmt->execute(array($this->first_name, $this->last_name, $this->id));



        }
        static function getUserByPass(PDO $db, string $username, string $password) : ?User {
            $stmt = $db->prepare(
                'SELECT * FROM User WHERE Email = ? AND Password = ?'
            );
            if($user = $stmt->fetch()){
                return new User($user['id'], $user['first_name'], $user['last_name'], $user['email'], $user['password'], $user['username'], $user['is_client'], $user['is_agent'], $user['is_admin']);
            } else {
                return null;
            }
        }

        function getUser(PDO $db, int $id){
            $stmt = $db->prepare(
                'SELECT * FROM Customer WHERE CustomerId = ?'
            );
            $stmt->execute(array($id));
            $user = $stmt->fetch();
            
            
            return new User($user['id'], $user['first_name'], $user['last_name'], $user['email'], $user['password'], $user['username'], $user['is_client'], $user['is_agent'], $user['is_admin']);
        }

}

?>