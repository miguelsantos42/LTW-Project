.mode columns
.headers on

PRAGMA foreign_keys = ON;

DROP TABLE IF EXISTS Ticket;
DROP TABLE IF EXISTS FAQ;
DROP TABLE IF EXISTS Status;
DROP TABLE IF EXISTS Admin;
DROP TABLE IF EXISTS AgentDepartment;
DROP TABLE IF EXISTS Agent;
DROP TABLE IF EXISTS Department;
DROP TABLE IF EXISTS Client;

create table Client (
	id INT,
	first_name VARCHAR(50),
	last_name VARCHAR(50),
	email VARCHAR(50),
	gender VARCHAR(50),
	password VARCHAR(50),
	username VARCHAR(50),
    PRIMARY KEY(id)
);

create table Department(
    id INT,
    name VARCHAR(50),
    PRIMARY KEY(id)
);

create table Agent (
	id INT,
	FOREIGN KEY (id) REFERENCES Client(id) ON DELETE CASCADE ON UPDATE CASCADE,
    PRIMARY KEY(id)

);

create table AgentDepartment(
    agent_id INT,
    department_id Int,
    FOREIGN KEY(department_id)  REFERENCES Department(id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (agent_id) REFERENCES Agent(id) ON DELETE CASCADE ON UPDATE CASCADE,
    PRIMARY KEY (agent_id, department_id)
);

create table Admin (
	id INT,
	FOREIGN KEY (id) REFERENCES Agent(id) ON DELETE CASCADE ON UPDATE CASCADE,
    PRIMARY KEY(id)

);

create table Status(
    id INT,
    name VARCHAR(50),
    color VARCHAR(50)
);

create table Ticket(
    id INT,
    client_id INT,
    department_id INT,
    description text,
    date_submission DATE,
    priority VARCHAR(1),
    agent_id INT,
    status_id INT,
    PRIMARY KEY(id),
    FOREIGN KEY(client_id) REFERENCES Client(id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY(department_id)  REFERENCES Department(id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (agent_id) REFERENCES Agent(id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (status_id) REFERENCES Status(id) ON DELETE CASCADE ON UPDATE CASCADE
);

create table FAQ(
    id INT,
    question TEXT,
    response TEXT,
    department_id INT,
    PRIMARY KEY (id),
    FOREIGN KEY(department_id)  REFERENCES Department(id) ON DELETE CASCADE ON UPDATE CASCADE
);

