insert into Clients (id, first_name, last_name, email, gender, password, username) values (1, 'Galina', 'Downie', 'gdownie0@oaic.gov.au', 'Female', 'VqnLLLHL8F6', 'gdownie0');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (2, 'Bamby', 'Macilhench', 'bmacilhench1@studiopress.com', 'Female', 'dbSzCmabEu', 'bmacilhench1');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (3, 'Ebenezer', 'Medley', 'emedley2@pinterest.com', 'Male', 'UdhGf0sh', 'emedley2');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (4, 'Ulysses', 'Scryne', 'uscryne3@va.gov', 'Male', 'eAKcVHf2GFx', 'uscryne3');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (5, 'Isac', 'Bartoletti', 'ibartoletti4@earthlink.net', 'Male', 'aDCYyZk', 'ibartoletti4');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (6, 'Robb', 'Durward', 'rdurward5@vinaora.com', 'Male', 'jaF458qrKf', 'rdurward5');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (7, 'Etty', 'Syrad', 'esyrad6@istockphoto.com', 'Female', 'SZbWiHA1Pnkq', 'esyrad6');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (8, 'Heidi', 'Mizzen', 'hmizzen7@discuz.net', 'Female', 'EWJFPyviB98u', 'hmizzen7');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (9, 'Lyn', 'Kenion', 'lkenion8@arizona.edu', 'Male', 'AqSrkrgrqWQ', 'lkenion8');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (10, 'Crichton', 'Cadman', 'ccadman9@cmu.edu', 'Male', '2G5xlsLJ', 'ccadman9');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (11, 'Myrtle', 'McEwan', 'mmcewana@sohu.com', 'Female', 'ji5WT6', 'mmcewana');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (12, 'Orv', 'Nowlan', 'onowlanb@businesswire.com', 'Male', '1GeaGzW3OOPh', 'onowlanb');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (13, 'Howard', 'Dallicott', 'hdallicottc@ustream.tv', 'Male', 'SFTiWZES1O', 'hdallicottc');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (14, 'Skell', 'Benazet', 'sbenazetd@reverbnation.com', 'Male', 'efJozv', 'sbenazetd');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (15, 'Dolly', 'Balasini', 'dbalasinie@t-online.de', 'Female', 'cp6BpsO9', 'dbalasinie');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (16, 'Lucien', 'Loines', 'lloinesf@wiley.com', 'Male', 'b6OF6eeWn', 'lloinesf');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (17, 'Janessa', 'Birkin', 'jbirking@infoseek.co.jp', 'Female', 'cdEo8Tv', 'jbirking');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (18, 'Sharlene', 'Diamant', 'sdiamanth@networksolutions.com', 'Female', 'EZXvZaQ', 'sdiamanth');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (19, 'Archibold', 'Brownhall', 'abrownhalli@squarespace.com', 'Male', 'gBKdMlii', 'abrownhalli');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (20, 'Berte', 'Pavlovsky', 'bpavlovskyj@studiopress.com', 'Female', 'Rv4hpiJw8', 'bpavlovskyj');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (21, 'Marcello', 'Whopples', 'mwhopplesk@wp.com', 'Male', 'JHR02xc', 'mwhopplesk');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (22, 'Padraic', 'Brimilcome', 'pbrimilcomel@unblog.fr', 'Male', 'vUJWktHWh', 'pbrimilcomel');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (23, 'Pamella', 'Edlington', 'pedlingtonm@uol.com.br', 'Female', 'X52FP4yMp', 'pedlingtonm');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (24, 'Mitzi', 'Luby', 'mlubyn@aol.com', 'Female', 'RmrULMNm', 'mlubyn');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (25, 'Dario', 'Gouch', 'dgoucho@cpanel.net', 'Male', '1U0fxe', 'dgoucho');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (26, 'Reg', 'Sammars', 'rsammarsp@acquirethisname.com', 'Male', 'ovNpAy', 'rsammarsp');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (27, 'Alaster', 'Lardez', 'alardezq@xing.com', 'Male', '8CqKgUC5', 'alardezq');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (28, 'Lyman', 'Lemmanbie', 'llemmanbier@webmd.com', 'Male', 'wtVPoNKBi', 'llemmanbier');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (29, 'Gil', 'Tideswell', 'gtideswells@simplemachines.org', 'Male', '83xjp1yL9pT', 'gtideswells');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (30, 'Jock', 'Foli', 'jfolit@multiply.com', 'Male', 'J4ZMEkw9F2q', 'jfolit');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (31, 'Mischa', 'Pumfrett', 'mpumfrettu@nhs.uk', 'Male', 'e7ft0u2X', 'mpumfrettu');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (32, 'Karlene', 'Crumb', 'kcrumbv@tmall.com', 'Female', 'seEjsRijGfU', 'kcrumbv');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (33, 'Aila', 'Jockle', 'ajocklew@opera.com', 'Female', 'NWbT7d', 'ajocklew');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (34, 'Kali', 'Servant', 'kservantx@vk.com', 'Female', 'bBW2Jk7', 'kservantx');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (35, 'Nannette', 'Jeandin', 'njeandiny@google.de', 'Female', 'Ba0ixb9l', 'njeandiny');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (36, 'Duncan', 'Coarser', 'dcoarserz@sohu.com', 'Male', 'pd2kKbyFBIK', 'dcoarserz');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (37, 'Mart', 'Hargrove', 'mhargrove10@chronoengine.com', 'Male', 'nUrQ0ooeyiqh', 'mhargrove10');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (38, 'Henry', 'Fleming', 'hfleming11@yale.edu', 'Male', 'CQYPve4AUgb', 'hfleming11');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (39, 'Susan', 'Hovenden', 'shovenden12@cmu.edu', 'Female', '6MVdF7vUO8', 'shovenden12');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (40, 'Nonie', 'Blackshaw', 'nblackshaw13@nbcnews.com', 'Female', 'U2fL4Fb', 'nblackshaw13');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (41, 'Roderick', 'Pickthorn', 'rpickthorn14@baidu.com', 'Male', 'UZ2two', 'rpickthorn14');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (42, 'Kelbee', 'Leber', 'kleber15@cbc.ca', 'Male', 'UQrz6yJCYjig', 'kleber15');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (43, 'Matilde', 'Bartley', 'mbartley16@topsy.com', 'Female', 'GLe0sl9GepD', 'mbartley16');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (44, 'Hendrick', 'Whenham', 'hwhenham17@imdb.com', 'Male', 'Kap1jQQDh', 'hwhenham17');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (45, 'Laurella', 'Barnicott', 'lbarnicott18@reddit.com', 'Female', 'qnJtjEepol', 'lbarnicott18');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (46, 'Collen', 'Capron', 'ccapron19@weebly.com', 'Female', 'wJjPz6MZ', 'ccapron19');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (47, 'Vallie', 'North', 'vnorth1a@guardian.co.uk', 'Female', '0XRrlymPNn', 'vnorth1a');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (48, 'Scotty', 'Barts', 'sbarts1b@usa.gov', 'Male', 'o9Rejfrw', 'sbarts1b');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (49, 'Hadria', 'Megroff', 'hmegroff1c@blinklist.com', 'Female', 'rNW0aG6F', 'hmegroff1c');
insert into Clients (id, first_name, last_name, email, gender, password, username) values (50, 'Brucie', 'Luney', 'bluney1d@ehow.com', 'Male', 'q6vzrUpLDJSY', 'bluney1d');

insert into Agent (id) values ('13');
insert into Agent (id) values ('28');
insert into Agent (id) values ('37');
insert into Agent (id) values ('14');
insert into Agent (id) values ('25');
insert into Agent (id) values ('3');
insert into Agent (id) values ('50');
insert into Agent (id) values ('5');
insert into Agent (id) values ('39');
insert into Agent (id) values ('44');

insert into Admin (id) values ('14');
insert into Admin (id) values ('44');
insert into Admin (id) values ('39');

insert into Department (id, name) values (1, 'Sales');
insert into Department (id, name) values (2, 'Accounting');
insert into Department (id, name) values (3, 'Human Resources');

insert into AgentDepartment (agent_id, department_id) values ('13', '1');
insert into AgentDepartment (agent_id, department_id) values ('28', '1');
insert into AgentDepartment (agent_id, department_id) values ('37', '2');
insert into AgentDepartment (agent_id, department_id) values ('14', '2');
insert into AgentDepartment (agent_id, department_id) values ('25', '2');
insert into AgentDepartment (agent_id, department_id) values ('3', '2');
insert into AgentDepartment (agent_id, department_id) values ('50', '3');
insert into AgentDepartment (agent_id, department_id) values ('5', '1');
insert into AgentDepartment (agent_id, department_id) values ('39', '1');
insert into AgentDepartment (agent_id, department_id) values ('44', '1');

insert into Status (id, name, color) values (1, 'Open', '#29ebe8');
insert into Status (id, name, color) values (2, 'In Progress', '#86971c');
insert into Status (id, name, color) values (3, 'Closed', '#a6ba2c');

insert into Ticket (id, client_id, department_id, description, date_submission, priority, agent_id, status_id) values (1, '32', '2', 'In hac habitasse platea dictumst. Etiam faucibus cursus urna. Ut tellus. Nulla ut erat id mauris vulputate elementum. Nullam varius. Nulla facilisi.', '23/07/2022', 1, '3', '2');
insert into Ticket (id, client_id, department_id, description, date_submission, priority, agent_id, status_id) values (2, '13', '1', 'Nulla ut erat id mauris vulputate elementum. Nullam varius. Nulla facilisi.', '11/01/2023', 1, '5', '1');
insert into Ticket (id, client_id, department_id, description, date_submission, priority, agent_id, status_id) values (3, '5', '3', 'pharetra magna, ac consequat metus sapien ut nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam. Suspendisse potenti. Nullam .', '20/09/2022', 3, '50', '3');
insert into Ticket (id, client_id, department_id, description, date_submission, priority, agent_id, status_id) values (4, '27', '1', 'Nullam sit amet turpis elementum ligula vehicula consequat. Morbi a ipsum. Integer a nibh.', '08/08/2022', 1, '39', '1');
insert into Ticket (id, client_id, department_id, description, date_submission, priority, agent_id, status_id) values (5, '34', '2', 'Maecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam. Suspendisse potenti. Nullam porttitor lacus at turpis. Donec posuere metus vitae ipsum. Aliquam non mauris.', '01/09/2022', 1, '14', '2');




